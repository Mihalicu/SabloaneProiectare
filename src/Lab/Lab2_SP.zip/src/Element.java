public class Element {
    public void print() {

    }

    public Element() {

    }
}
