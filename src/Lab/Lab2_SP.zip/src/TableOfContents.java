public class TableOfContents {
    public void print()
    {

    }
}
