public class Author {
    private String name;

    public void print()
    {

    }

    public Author(String name) {
        this.name = name;
    }
}
